var tnAdditionalParams = {'main_domain': 'znnmt.com', 'block_id': fbdf7e88aa26, 'pad_id': f13395416d};
document.write('<script type="text/javascript" src="//web.archive.org/web/20170603210148/http://znnmt.com/js/b0f43350a68c.js?' + fbdf7e88aa26 + '&' + f13395416d + '&a=&znnmt.com"></script>');
//3206
/*
     FILE ARCHIVED ON 21:01:48 Jun 03, 2017 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:01:50 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  exclusion.robots: 0.38
  exclusion.robots.policy: 0.361
  RedisCDXSource: 0.912
  load_resource: 80.157
  CDXLines.iter: 14.555 (3)
  PetaboxLoader3.datanode: 70.019 (4)
  esindex: 0.019
  captures_list: 103.121
  LoadShardBlock: 83.204 (3)
  PetaboxLoader3.resolve: 24.398
*/