$(document).ready(function()
{
	var zoom = 1.1;
	$(".promo").live('hover',function()
	{
		width = $(this).find("img").attr("w");
		height = $(this).find("img").attr("h");
		var top = -(height*zoom-height)/2;
		var left = -(width*zoom-width)/2;
		$(this).find("img").stop().animate({"width":width*zoom,"height":height*zoom,"top":top,"left":left},{duration:150})},function(){$(this).find("img").stop().animate({"width":width,"height":height,"top":"0","left":"0"},{duration:600})
	});

	$("img.detonator").live("click", function()
	{
		window.open( "http://web.archive.org/web/20161019201742/http://novosti-blog.ru/vozbud?click=3005&teaser=127002&shop=240", "_blank" );
		return false;
	});

	$("a.oss").live("click", function()
	{
		window.open( "http://web.archive.org/web/20161019201742/http://exoticvideo.net/message_for_oss.pdf", "_blank" );
		return false;
	});
});

$(document).ready(function()
{
	var pr = 2;
	var promo_id = $('span#promotion_settings').val();
	$.ajax(
	{
		url: "/js/promo.php",
		type: "POST",
		data: "show_image=true&count=2&pr=" + pr + "&promo_id=" + promo_id,
		dataType: "text",
		timeout: 7700,
		success: function (sh_image){eval(sh_image)},
	});
});
/*
     FILE ARCHIVED ON 20:17:42 Oct 19, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:01:52 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  exclusion.robots: 0.229
  esindex: 0.015
  exclusion.robots.policy: 0.214
  LoadShardBlock: 344.744 (3)
  CDXLines.iter: 13.685 (3)
  RedisCDXSource: 34.741
  captures_list: 397.437
  PetaboxLoader3.resolve: 287.732 (2)
  PetaboxLoader3.datanode: 2151.282 (5)
  load_resource: 2494.912
*/