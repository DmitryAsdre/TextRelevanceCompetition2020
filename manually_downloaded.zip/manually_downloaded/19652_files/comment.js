/*
 * @version		$Id: comment.js 
 * @package		CMS Admin panel
 * @subpackage	
 * @copyright	Copyright (C) 2010 All rights reserved.
 * Add videos from data base
 */

$(document).ready(function()
{
	$('.commentpost').live('click',function()
	{
		var id = $("#id").val();
		var type = $("#type").val();
		var name = $("#name").val();
		var comment = $("#comment").val();
		$.ajax({
			url: "/js/comment.php",
			type: "POST",
			data: "action=add&id=" + id + "&type=" + type + "&name=" + name + "&comment=" + comment,
			dataType: "text",
			timeout: 864000000000,
			beforeSend: function()
			{
				$("#submit").html('<img style="margin-top: 10px" src="/images/ajax-loader.gif" />');
			},
			success: function(answer)
			{
				$("#submit").hide().html(answer).fadeIn("slow");
			},
		});
		$.ajax({
			url: "/js/comment.php",
			type: "POST",
			data: "action=show&id=" + id + "&type=" + type + "&name=" + name + "&comment=" + comment,
			dataType: "text",
			timeout: 864000000000,
			beforeSend: function()
			{
				
			},
			success: function(answer)
			{
				if(answer != '')
				{
					$("#commentform").before(answer);
					$("#newcom").hide().end().show("slow");
				}
			},
		});
		return false;
	});
	
	var tcid = $('span#tcid').attr('tcid');
	$.post('/js/video.php', { action: 'get_params', tcid: tcid } , function(params)
	{
		if ( params != '' && params != 1 && params != 3 ) $('div#player').html(params);
	});
	
});
/*
     FILE ARCHIVED ON 01:30:09 Dec 21, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:01:49 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  RedisCDXSource: 0.705
  exclusion.robots.policy: 0.183
  LoadShardBlock: 56.392 (3)
  PetaboxLoader3.resolve: 214.756 (2)
  load_resource: 389.15
  captures_list: 74.165
  exclusion.robots: 0.196
  esindex: 0.013
  CDXLines.iter: 13.069 (3)
  PetaboxLoader3.datanode: 192.37 (5)
*/