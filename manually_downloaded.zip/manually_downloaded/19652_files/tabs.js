(function($)
{
	$(function()
	{
		$('ul.tabs').delegate('li:not(.current)', 'click', function()
			{
				$(this).addClass('current').siblings().removeClass('current')
				.parents('div.additional').find('div.box').hide().eq($(this).index()).show();
			})
	})
})(jQuery)
/*
     FILE ARCHIVED ON 01:19:13 Dec 21, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:01:49 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  LoadShardBlock: 210.015 (3)
  PetaboxLoader3.resolve: 445.958 (3)
  exclusion.robots: 0.153
  exclusion.robots.policy: 0.142
  captures_list: 229.893
  CDXLines.iter: 11.095 (3)
  RedisCDXSource: 4.982
  PetaboxLoader3.datanode: 290.356 (5)
  load_resource: 590.818
  esindex: 0.017
*/