/*
 * @version		$Id: addfavorite.js 
 * @package		CMS
 * @subpackage	
 * @copyright	Copyright (C) 2010 All rights reserved.
 * Add favorite script
 */

function add_favorite(a)
{
	title=document.title; 
	url=document.location; 
	try 
	{
		// Internet Explorer 
		window.external.AddFavorite(url, title); 
	} 
	catch (e)
	{
		try
		{
			// Mozilla 
			window.sidebar.addPanel(title, url, ""); 
		}
		catch (e)
		{
			// Opera 
			if (typeof(opera)=="object")
			{
				a.rel="sidebar"; 
				a.title=title; 
				a.url=url; 
				return true; 
			} 
			else
			{
				// Unknown
				alert('Нажмите Ctrl-D чтобы добавить страницу в закладки');
			}
		}
	}
	return false; 
}
/*
     FILE ARCHIVED ON 20:01:44 Oct 19, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:01:51 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 780.181
  exclusion.robots: 0.295
  CDXLines.iter: 15.985 (3)
  PetaboxLoader3.datanode: 638.871 (5)
  load_resource: 185.95
  LoadShardBlock: 750.279 (3)
  esindex: 0.023
  PetaboxLoader3.resolve: 66.61 (2)
  RedisCDXSource: 8.594
  exclusion.robots.policy: 0.277
*/