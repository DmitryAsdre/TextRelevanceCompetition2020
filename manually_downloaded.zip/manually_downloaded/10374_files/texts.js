var objTexts={
	t0_source:	"БОЙ ТОЛЬКО<n>НАЧИНАЕТСЯ",	
	t1_source:	"ПОПАДИ<n>В ЭПИЦЕНТР<n>СРАЖЕНИЯ",	
	t2_source:	"ДАЙ ОТПОР<n>ПРОТИВНИКУ",	
	btn_source:	"НАЧНИ ИГРУ"
}




