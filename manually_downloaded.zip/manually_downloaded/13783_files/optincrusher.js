// client side code based on catfish ad tutorial from sitepoint
// http://www.sitepoint.com/blogs/2005/10/18/the-catfish-part-1/
// http://www.sitepoint.com/blogs/2005/10/21/catfish-ads-part-2/

// Deploy the footer

// The footer optin form should be located in an element (DIV) of id 'footer' and should be hidden
// out of view (hidden by initial CSS)

// Stack up window.onload events using this function from Simon Willison -
// http://www.sitepoint.com/blog-post-view.php?id=171578
function addLoadEvent(func) {
	var oldonload = window.onload;
	if (typeof window.onload != 'function') {
		window.onload = func;
	} else {
		window.onload = function() {
			oldonload();
			func();
		}
	}
}

function registerHideme() {
	var hidelink = document.getElementById('hideme');
	hidelink.onclick = hidefooter;

}

function registerShowme() {
	var showlink = document.getElementById('optincrushershow');
	showlink.onclick = showfooter;
}

addLoadEvent(function() {
	registerHideme();
	registerShowme();
});

// lightbox functions
function showLightBox() {
	document.getElementById('light').style.display='block';
	document.getElementById('fade').style.display='block'
}

function hideLightBox() {
	document.getElementById('light').style.display='none';
	document.getElementById('fade').style.display='none'
}

// layer animation
var showbuttonLayerStatus = Array ();
showbuttonLayerStatus['layerHeight'] = 0;
showbuttonLayerStatus['layerPosition'] = 0;

var footerLayerStatus = Array ();
footerLayerStatus['layerHeight'] = 0;
footerLayerStatus['layerPosition'] = 0;

function showfooterinitial() {	
	if (rememberShowHideState && getCookie('show_hide_state') == 'hide') {
		setTimeout(function(){scrollLayer ('optincrushershow', showbuttonheight, 'show', footerLayerStatus)}, displayDelay);
	} else{
		setTimeout(function(){scrollLayer ('optincrusher', footerheight, 'show', showbuttonLayerStatus, true)}, displayDelay);		
	}
}

function showfooter() {
	scrollLayer ('optincrusher', footerheight, 'show', showbuttonLayerStatus, true);
	scrollLayer ('optincrushershow', showbuttonheight, 'hide', footerLayerStatus);
	delCookie('show_hide_state');	// delete cookie so that it shows by default
}

function hidefooter() {
	scrollLayer ('optincrusher', footerheight, 'hide', showbuttonLayerStatus, true);
	scrollLayer ('optincrushershow', showbuttonheight, 'show', footerLayerStatus);
	setCookie('show_hide_state','hide','/',31);	// don't show for a month, unless then show it
}

function scrollLayer ( whichLayer, height, action, statusArray, modifyBottomPadding ) {
	// get handle for the div to animate
	statusArray['layerToScroll'] = document.getElementById(whichLayer);

	// begin animation
	statusArray['layerHeight'] = height;
	statusArray['layerPosition'] = (action == 'show') ? 0:100; // statusArray['layerPosition'] is expressed as a percentage (out of 100);
	statusArray['layerTimeout'] = setInterval(function(){positionLayer(action, statusArray, modifyBottomPadding)}, slidespeed);
}

// position the layer (see scrollLayer which initializes the timeout for this function call)
function positionLayer(action, statusArray, modifyBottomPadding) {
	if (action == 'show') {
		statusArray['layerPosition'] += slidestep;
	} else if (action == 'hide') {
		statusArray['layerPosition'] -= slidestep;
	}

	// the magic 100s below indicate percentage with the layer approaching 100% shown/hidden
	statusArray['layerToScroll'].style.marginBottom = '-' + (((100 - statusArray['layerPosition']) / 100) * statusArray['layerHeight']) + 'px';

	// if I'm 100% deployed then finish footer
	if ((action == 'show' && statusArray['layerPosition'] >= 100) || (action == 'hide' && statusArray['layerPosition'] <= 0)) {
		clearTimeout(statusArray['layerTimeout']);
		if (modifyBottomPadding) statusArray['layerTimeout'] = setTimeout(function(){finishLayer(action, statusArray)}, 1);
	}
}

function finishLayer(action, statusArray) {
	// just in case we overdeployed in positionfooter(), ensure marginBottom is zero (0)
	statusArray['layerToScroll'].style.marginBottom = (action == 'hide') ? '-'+statusArray['layerHeight']+'px':'0px';

	// increase padding at bottom of document so that page content isn't hidden under
	// the footer when the page is scrolled all the way to the bottom
	document.body.parentNode.style.paddingBottom = (action == 'hide') ? attributionoffset + 'px':(statusArray['layerHeight'] - footeroverlap + attributionoffset) +'px';

	// here you could use AJAX (or similar) to log the popup hit for tracking purposes
}

addLoadEvent(showfooterinitial);
// cookie management functions below

function setCookie(c_name,value,path,expiredays) {
	var exdate = new Date();
	exdate.setDate(exdate.getDate()+expiredays);
	document.cookie = c_name + "=" + escape(value) + (path ? '; path=' + path : '') + ((expiredays==null) ? "" : ";expires=" + exdate.toGMTString());
}

function getCookie(c_name) {
	if (document.cookie.length>0) {
		c_start=document.cookie.indexOf(c_name + "=");
		if (c_start!=-1) {
			c_start=c_start + c_name.length+1;
			c_end=document.cookie.indexOf(";",c_start);
			if (c_end==-1) c_end=document.cookie.length;
			return unescape(document.cookie.substring(c_start,c_end));
		}
	}
	return "";
}

// this deletes the cookie when called
function delCookie(c_name) {
	var tmp = getCookie(c_name);
	if(tmp) { setCookie(c_name,tmp,'/',-1); }
}
/*
     FILE ARCHIVED ON 20:08:40 Feb 05, 2013 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:19:56 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  load_resource: 291.085
  exclusion.robots: 0.144
  RedisCDXSource: 34.511
  captures_list: 188.087
  esindex: 0.015
  LoadShardBlock: 136.352 (3)
  PetaboxLoader3.datanode: 150.346 (4)
  PetaboxLoader3.resolve: 258.123
  CDXLines.iter: 12.486 (3)
  exclusion.robots.policy: 0.133
*/