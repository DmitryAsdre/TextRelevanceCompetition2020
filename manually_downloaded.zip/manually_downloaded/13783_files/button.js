
/*
     FILE ARCHIVED ON 17:26:22 Oct 28, 2012 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:19:54 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  LoadShardBlock: 143.246 (3)
  PetaboxLoader3.resolve: 79.684 (2)
  exclusion.robots: 0.217
  exclusion.robots.policy: 0.203
  captures_list: 200.588
  CDXLines.iter: 17.128 (3)
  RedisCDXSource: 23.629
  PetaboxLoader3.datanode: 100.482 (4)
  load_resource: 75.163
  esindex: 0.009
*/