$(document).ready(function(){

// == Редирект по клику на "Главная" == //
$('#si_onmain').click(function(){
document.location.href='/';
});


// == Кнопка Наверх == //
$(window).scroll(function () {if ($(this).scrollTop() > 0) {$('#scroller').fadeIn();} else {$('#scroller').fadeOut();}});
$('#scroller').click(function () {$('body,html').animate({scrollTop: 0}, 400); return false;});

});


/*
     FILE ARCHIVED ON 23:16:04 Mar 25, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:46:29 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  exclusion.robots: 0.226
  esindex: 0.017
  exclusion.robots.policy: 0.211
  LoadShardBlock: 493.741 (3)
  CDXLines.iter: 16.296 (3)
  RedisCDXSource: 4.572
  captures_list: 520.397
  PetaboxLoader3.resolve: 359.06 (3)
  PetaboxLoader3.datanode: 725.871 (5)
  load_resource: 988.65
*/