// == Функция разбора результата == //
function mn_rparse(r) {
var a={};  // Создаём ассоциативный массив под результат
r=r.split('&');  // Разрезаем полученные данные по &
$.each(r, function(n, v) {  // Перебираем получившийся массив
v=v.split('=');  // Разрезаем каждый элемент по =
a[v[0]]=v[1];  // Присваиваем значения в массиве под результат
});
return a;  // Возвращаем результат
}
/*
     FILE ARCHIVED ON 13:03:33 Nov 06, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:46:28 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  RedisCDXSource: 31.675
  load_resource: 728.728
  esindex: 0.013
  captures_list: 204.428
  exclusion.robots.policy: 0.175
  exclusion.robots: 0.188
  PetaboxLoader3.datanode: 115.217 (5)
  CDXLines.iter: 13.911 (3)
  LoadShardBlock: 155.573 (3)
  PetaboxLoader3.resolve: 395.984 (3)
*/