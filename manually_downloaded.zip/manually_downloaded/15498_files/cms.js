$('document').ready(function(){

  $('.comm_edit_btn').click(function(){
    var rs = prompt('Редактировать комментарий', $(this).attr('code'));
    $.post(window.location, mn_dr+'act=comm_edit&comm_id='+$(this).attr('commid')+'&code='+rs, function(r){  // Совешаем действие
      if(r=='ok') location.reload();
    });
  });
  
  $('.email').each(function() {
		$(this).html($(this).html().replace('<dog>', '@'));
  });

});

/*
     FILE ARCHIVED ON 12:45:59 Nov 06, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:46:29 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  PetaboxLoader3.datanode: 89.382 (4)
  captures_list: 98.921
  PetaboxLoader3.resolve: 53.166
  CDXLines.iter: 12.436 (3)
  esindex: 0.011
  RedisCDXSource: 3.74
  exclusion.robots.policy: 0.266
  load_resource: 106.975
  exclusion.robots: 0.28
  LoadShardBlock: 79.599 (3)
*/