var sidebar_open=0;
var login_open=false;

$(document).ready(function() {
	$('#si_panel .left .icon-menu').click(function() {
		if(sidebar_open!=1) {
			if(sidebar_open==2) $('#si_right').animate({'left': '100%'});
			$('#si_left').animate({'left': '0px'});
			sidebar_open=1;
		} else {
			$('#si_left').animate({'left': '-100%'});
			sidebar_open=0;
		}
	});
	
	$('#si_panel .right .icon-menu').click(function() {
		if(sidebar_open!=2) {
			if(sidebar_open==1) $('#si_left').animate({'left': '-100%'});
			$('#si_right').animate({'left': ($(document).width()-$('#si_right').width())+'px'});
			sidebar_open=2;
		} else {
			$('#si_right').animate({'left': '100%'});
			sidebar_open=0;
		}
	});

	$('#si_login_btn').click(function() {
		if(login_open==false) {
			$('#si_login_popup').show();
			login_open=true;
		} else {
			$('#si_login_popup').hide();
			login_open=false;		
		}
	});

});
/*
     FILE ARCHIVED ON 13:34:02 Nov 06, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:48:12 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  esindex: 0.011
  exclusion.robots: 0.209
  load_resource: 78.697
  RedisCDXSource: 18.443
  LoadShardBlock: 95.625 (3)
  PetaboxLoader3.resolve: 99.441 (2)
  PetaboxLoader3.datanode: 60.145 (4)
  exclusion.robots.policy: 0.196
  captures_list: 131.343
  CDXLines.iter: 14.111 (3)
*/