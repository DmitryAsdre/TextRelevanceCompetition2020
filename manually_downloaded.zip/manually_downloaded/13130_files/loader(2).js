var ya = ya || {};

ya.yobject = (function() {
    var YO_LAST_VERSION = 'https://yastatic.net/yobject/2.5.1/core.min.js',
        DEFAULT_CLIENT_KEY = 2246354;

    return {
        load: function (article, options) {
            var script = document.createElement('script');

            options = options || {};
            options.clientKey = options.clientKey || DEFAULT_CLIENT_KEY;

            script.charset = 'utf-8';
            script.type = 'text/javascript';
            script.src = options.src || YO_LAST_VERSION;
            
            script.onload = function() {
                YINFO.parseAPIObjects(article, options);
            };
            script.onerror = function(data) {
                console.log("Error: " + JSON.stringify(data));
            };

            document.getElementsByTagName('head')[0].appendChild(script);
        }
    };
})();
