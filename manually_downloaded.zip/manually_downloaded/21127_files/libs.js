$(function() {

  $( "#polldialog" ).dialog({
    autoOpen: false,
    width: 450
  });

  $('#polllink').click(function(){
    $('#polldialog').dialog('open');
    return false;
  });
});

$(document).ready(function(){
    $('#topmenu li.sublnk').hover(
    function() {
      $(this).addClass("selected");
      $(this).find('ul').stop(true, true);
      $(this).find('ul').show('fast');
    },
    function() {
      $(this).find('ul').hide('fast');
      $(this).removeClass("selected");
    }
  );
});













    $(document).ready(function() {
      
      $('.carousel').elegantcarousel({
          delay:50,
          fade:300,
          slide:500,
          effect:'fade',            
          orientation:'horizontal',
          loop: false,
          autoplay: false,
          time: 5000      });
      
      $('.open_config').click(function() {
                       
        var display = $('.config_inner').css('display');
        if(display == 'none') { $('.config_inner').fadeIn(200); }                 
        if(display == 'block') { $('.config_inner').fadeOut(200); }  
        return(false);
       });

      
      function center_main() {
        var window_height = $(window).height();
        var main_height = parseInt($('#main').css('height'));
        var main_height_margin = (window_height - main_height) / 2;
        $('#main').css('top',Math.floor(main_height_margin));
      }
      center_main();
  
    });




(function($) {
$(function() {
  $('ul.tabs').delegate('li:not(.current)', 'click', function() {
    $(this).addClass('current').siblings().removeClass('current')
      .parents('div.section').find('div.box').hide().eq($(this).index()).fadeIn(150);
  })
})
})(jQuery);


$(function () {
	$(".lcomment:odd").addClass("even");
	$(".lcomment").hover(function(){ $(this).addClass("hover");},function(){$(this).removeClass("hover");});
	$('.lcomment').click(function(){window.location=$(this).find("a").attr("href"); return false;});
	});
/*
     FILE ARCHIVED ON 06:16:55 Mar 09, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:49:09 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  exclusion.robots: 0.134
  esindex: 0.01
  exclusion.robots.policy: 0.123
  LoadShardBlock: 319.714 (3)
  CDXLines.iter: 12.912 (3)
  RedisCDXSource: 5.409
  captures_list: 342.414
  PetaboxLoader3.resolve: 200.825 (2)
  PetaboxLoader3.datanode: 473.586 (5)
  load_resource: 440.178
*/