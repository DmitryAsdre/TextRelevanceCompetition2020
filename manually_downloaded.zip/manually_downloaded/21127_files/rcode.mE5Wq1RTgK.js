(function(d){
		var e=d.createElement("style");
		var s=" .bn_mE5Wq1RTgK_table{width:100% !important;border-spacing:1px !important;table-layout:auto !important;background-color:#585858 !important} .bn_mE5Wq1RTgK_cell{text-align:center !important;padding:3px !important;background-color:# !important;vertical-align:top !important} .bn_mE5Wq1RTgK_cont{text-decoration:none !important;display:block !important;margin:0 !important;padding:0 !important} .bn_mE5Wq1RTgK_title{font:12px Tahoma !important;color:#FFFFFF !important;text-decoration:none !important;font-weight:bold !important;float:none !important;margin:0 !important;padding:0 !important} .bn_mE5Wq1RTgK_img{margin:0px !important;padding:0 !important;border: 0 !important;width:120px !important;height:120px !important} .bn_mE5Wq1RTgK_desc{font:12px Tahoma !important;color:#FFFFFF !important;text-decoration: none !important;font-weight:normal !important;float:none !important;margin:0 !important;padding:0 !important} .bn_mE5Wq1RTgK_link{font:12px Tahoma !important;color:#009a28 !important;font-weight:normal !important;float:none !important;margin:0 !important;padding:0 !important;text-decoration:none !important;border:0 !important} .bn_mE5Wq1RTgK_price{font:12px Tahoma !important;font-weight:bold !important;float:none !important;margin:0 !important;padding:0 !important}  .rc-link {width:61px !important;height:17px !important;padding:0 !important;display:block !important;background:url('http://web.archive.org/web/20160114164909/http://recreativ.ru/images/rc.png') no-repeat !important;float:right !important;overflow:hidden !important} .rc-link:hover {background-position: left -17px !important;}";
		e.setAttribute("type","text/css");
		var h=d.getElementsByTagName("head")[0];
		h.appendChild(e);
		if(e.styleSheet){ // IE
			e.styleSheet.cssText=s;
		}
		else{
			var t=d.createTextNode(s);
			e.appendChild(t);
		}
	})(document);
	var rcblkmE5Wq1RTgK = document.getElementById('bn_mE5Wq1RTgK');
if(rcblkmE5Wq1RTgK){(function(d){var h=d.getElementsByTagName('head')[0];var e=d.createElement('link');e.setAttribute('rel','stylesheet');e.setAttribute('type','text/css');e.setAttribute('href','http://web.archive.org/web/20160114164909/http://recreativ.ru/css/rec_tr.css');h.appendChild(e);})(document);
	rcblkmE5Wq1RTgK.innerHTML = "<table border='0' cellpadding='1' cellspacing='1' class='bn_mE5Wq1RTgK_table'><tr><td width=50% class='bn_mE5Wq1RTgK_cell'><a href='http://web.archive.org/web/20160114164909/http://clk.recreativ.ru/go.php?clk=aWQ9MTUzMTUmdGlkPTgxNzM2MDQ0JnBjPWlmNndmNjZsNmJsZGZkN2RFaWZ2RWlsNkVpaWRFaWw4JmJudW09bUU1V3ExUlRnSyZybmQ9ODE0NTUwMDMyJmJ2PTEmaT03Njk3NzAwNzI3' target='_blank' title='Buy Lose weight easy' rel='nofollow' class='bn_mE5Wq1RTgK_cont'><img src='http://web.archive.org/web/20160114164909/http://st1.recreativ.ru/tizers/120/324/tiz-9I2aKbTZi1.jpg' target='_blank' class='bn_mE5Wq1RTgK_img'><div class='bn_mE5Wq1RTgK_title'>Lose weight easy</div><div title='Buy Lose weight easy' class='bn_mE5Wq1RTgK_desc'>Blast your fat and boost your metabolism with Asian Garcinia</div><div class='bn_mE5Wq1RTgK_link'>go2cloud.org</div> </a></td><td width=50% class='bn_mE5Wq1RTgK_cell'><a href='http://web.archive.org/web/20160114164909/http://clk.recreativ.ru/go.php?clk=aWQ9MTUzMTUmdGlkPTgxNzM2MDQ3JnBjPWlmNndmNjZsNmJsZGZkN2RFaWZ2RWlsNkVpaWRFaWw4JmJudW09bUU1V3ExUlRnSyZybmQ9ODE0NTUwMDMyJmJ2PTEmaT03Njk3NzAwNzI3' target='_blank' title='Buy Pure Asian Garcinia' rel='nofollow' class='bn_mE5Wq1RTgK_cont'><img src='http://web.archive.org/web/20160114164909/http://st1.recreativ.ru/tizers/120/175/tiz-X1fpiWmzke.jpg' target='_blank' class='bn_mE5Wq1RTgK_img'><div class='bn_mE5Wq1RTgK_title'>Pure Asian Garcinia</div><div title='Buy Pure Asian Garcinia' class='bn_mE5Wq1RTgK_desc'>Order now and start losing weight tomorrow!</div><div class='bn_mE5Wq1RTgK_link'>go2cloud.org</div> </a></td></tr><tr><td width=50% class='bn_mE5Wq1RTgK_cell'><a href='http://web.archive.org/web/20160114164909/http://clk.recreativ.ru/go.php?clk=aWQ9MTUzMTUmdGlkPTgxNzM2MDUwJnBjPWlmNndmNjZsNmJsZGZkN2RFaWZ2RWlsNkVpaWRFaWw4JmJudW09bUU1V3ExUlRnSyZybmQ9ODE0NTUwMDMyJmJ2PTEmaT03Njk3NzAwNzI3' target='_blank' title='Buy Pure Asian Garcinia' rel='nofollow' class='bn_mE5Wq1RTgK_cont'><img src='http://web.archive.org/web/20160114164909/http://st2.recreativ.ru/tizers/120/960/tiz-RxLxW1W3TU.jpg' target='_blank' class='bn_mE5Wq1RTgK_img'><div class='bn_mE5Wq1RTgK_title'>Pure Asian Garcinia</div><div title='Buy Pure Asian Garcinia' class='bn_mE5Wq1RTgK_desc'>Lose your weight without changing your diet!</div><div class='bn_mE5Wq1RTgK_link'>go2cloud.org</div> </a></td><td width=50% class='bn_mE5Wq1RTgK_cell'><a href='http://web.archive.org/web/20160114164909/http://clk.recreativ.ru/go.php?clk=aWQ9MTUzMTUmdGlkPTgxNzM2MDUzJnBjPWlmNndmNjZsNmJsZGZkN2RFaWZ2RWlsNkVpaWRFaWw4JmJudW09bUU1V3ExUlRnSyZybmQ9ODE0NTUwMDMyJmJ2PTEmaT03Njk3NzAwNzI3' target='_blank' title='Buy A key to beauty' rel='nofollow' class='bn_mE5Wq1RTgK_cont'><img src='http://web.archive.org/web/20160114164909/http://st2.recreativ.ru/tizers/120/956/tiz-ZUfSURdE97.jpg' target='_blank' class='bn_mE5Wq1RTgK_img'><div class='bn_mE5Wq1RTgK_title'>A key to beauty</div><div title='Buy A key to beauty' class='bn_mE5Wq1RTgK_desc'>Garcinia is recommendet by well known nutrition experts!</div><div class='bn_mE5Wq1RTgK_link'>go2cloud.org</div> </a><a href='http://web.archive.org/web/20160114164909/https://recreativ.ru' class='rc-link' title='Рекламная сеть Recreativ - с нами Вас заметят!' target='_blank' id='linkmE5Wq1RTgK'></a></td></tr></table>";
	rcblkmE5Wq1RTgK.style.padding = '0px';
	rcblkmE5Wq1RTgK.style.margin = '0px';
	var linkmE5Wq1RTgK=document.getElementById('linkmE5Wq1RTgK');
	if(linkmE5Wq1RTgK){
		setTimeout("linkmE5Wq1RTgK.style.margin=Math.max(0,linkmE5Wq1RTgK.parentElement.clientHeight-linkmE5Wq1RTgK.offsetTop-17)+'px 0 0 0'",200);
	}
}

(new Image()).src="//web.archive.org/web/20160114164909/http://cm.marketgid.com/m?cdsp=278776&c=7697700727";/*	15ms*/
/*
     FILE ARCHIVED ON 16:49:09 Jan 14, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:49:12 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  exclusion.robots.policy: 0.407
  load_resource: 194.815
  LoadShardBlock: 107.748 (3)
  RedisCDXSource: 4.355
  PetaboxLoader3.datanode: 211.101 (4)
  captures_list: 136.084
  exclusion.robots: 0.431
  CDXLines.iter: 18.417 (3)
  PetaboxLoader3.resolve: 58.268
  esindex: 0.023
*/