//1.0.4
/**
	Namespace module;
	methods:
		window.ADFOX.getNSReference
	properties:
		window.ADFOX
	Modify: 07-09-2015
*/
(function(){
	window.ADFOX = (window.ADFOX) || {};
	window.ADFOX.getNSReference = (window.ADFOX.getNSReference) || function(referenceString, value)
	{
		var referenceArray = referenceString.split('.'), 
			currentElement = window.ADFOX; 
			if (referenceArray[0] === "ADFOX") { 
				referenceArray = referenceArray.slice(1); 
			} 
			for (var i = 0, len = referenceArray.length; i < len ; i += 1) { 
				if (typeof currentElement[referenceArray[i]] === "undefined") { 
					currentElement[referenceArray[i]] = {}; 
				}
				currentElement = currentElement[referenceArray[i]]; 
			}
		return currentElement;
	};
})();

/**
	Embed code module;
	API in window.ADFOX.RELOAD_CODE:
		methods:
			loadBanner
				@param {String} placeholderId
				@param {String} requestSrc
				@param {Number} sessionId
			clearSession
			getSessionId
	API in window.ADFOX.RELOAD_CODE.embeds:
		properties:
			'<id баннерного места RELOAD_CODE>':{
				placeholderId: '<id placeholder adfox>',
				requestSrc: '<ссылка запроса за банером>'
			}
			
*/
(function(){
	var 
		tgEmbeds = window.ADFOX.getNSReference('RELOAD_CODE.embeds'),
		tgNS = window.ADFOX.getNSReference('RELOAD_CODE'),
		pageReferrer = (typeof(document.referrer) != 'undefined') ? escape(document.referrer) : '';
		
	/**
		API method;
		returns id for current session, id is the same for all request;
	*/
	function getSessionId()
	{
		tgNS.sessionId = (tgNS.sessionId) ? tgNS.sessionId : (Math.floor(Math.random() * 1000000));
		return tgNS.sessionId;
	}
	
	/**
		API method;
		clears current session; Subsequent getSessionId call will create new id;
	*/
	function clearSession()
	{
		tgNS.sessionId = 0;
	}
	
	/**
		Private method;
		sends new banner request, reuses existing iframe;
		@param {String} placeholderId
		@param {String} requestSrc
	*/
	function sendRequest(placeholderId, requestSrc){
		var iframeDocument = null,
			iframeId = 'AdFox_iframe_' + placeholderId,
			script = null,
			frameElement = document.getElementById(iframeId),
			parentFrameElement = frameElement.parentNode;

		parentFrameElement.appendChild(parentFrameElement.removeChild(frameElement));

		try{
			if(document.all && !window.opera){
				iframeDocument = window.frames[iframeId].document;
			}
			else if(document.getElementById){
				iframeDocument = frameElement.contentDocument;
			}
		}
		catch(e){}
		
		iframeDocument.write('<scr'+'ipt onerror="document.close();" type="text/javascript" src="'+requestSrc+'"><\/scr'+'ipt>');
	}
	
	/**
		API method;
		forms parameters for banner request, call sendRequest method;
		@param {String} placeholderId
		@param {String} requestSrc
		@param {Number} sessionId
	*/
	function loadBanner(placeholderId, requestSrc, sessionId){
		console.log('ADFOX loadBanner => AdFox_banner_' + placeholderId);
		var 
			addate = new Date(),
			dl = escape(document.location),
			ph = document.getElementById('AdFox_banner_'+placeholderId);

		var dynamicParameters = 
			'&amp;pt=b' +
			'&amp;prr=' + pageReferrer + //closure;
			'&amp;pr1=' + placeholderId + 
			'&amp;pr=' + sessionId +  
			'&amp;pd=' + addate.getDate() + 
			'&amp;pw=' + addate.getDay() + 
			'&amp;pv=' + addate.getHours() + 
			'&amp;dl=' + dl;

		(function() {
			var iframeWindow = null;
			try{
				if(document.all && !window.opera){
					iframeWindow = window.frames['AdFox_iframe_' + placeholderId];
				}
				else if(document.getElementById){
					iframeWindow = document.getElementById('AdFox_iframe_' + placeholderId).contentWindow;
				}
			}catch(e){}

			if (iframeWindow && typeof(iframeWindow.adfoxRemoveBanner) != 'undefined') {
				iframeWindow.adfoxRemoveBanner();
			}
		})();

		ph.innerHTML = '';
		ph.style.cssText = '';
		
		sendRequest(placeholderId, requestSrc + dynamicParameters);
	}

	function initBanner(bannerPlaceId,requestSrc) {
		var 
			pr1 = Math.floor(Math.random() * 1000000),
			placeholderHtml = '<div id="AdFox_banner_'+pr1+'"></div>',
			iframeHtml = '<div style="visibility:hidden; position:absolute;"><iframe id="AdFox_iframe_'+pr1+'" width=1 height=1 marginwidth=0 marginheight=0 scrolling=no frameborder=0></iframe></div>',
			html = placeholderHtml + '\n' + iframeHtml;

		tgEmbeds[bannerPlaceId] = {
				'placeholderId': pr1,
				'requestSrc': requestSrc
			};

		return {
			placeholderHtml: placeholderHtml,
			sessionId: getSessionId(),
			iframeHtml: iframeHtml,
			html: html,
			pr1: pr1
		};
	}
	
	function reloadBanners(bannerPlaceId) {
		var tgNS = window.ADFOX.getNSReference('RELOAD_CODE'),
			tgEmbeds = window.ADFOX.getNSReference('RELOAD_CODE.embeds');
			
		tgNS.clearSession();

		if (typeof(bannerPlaceId) == "object" || !bannerPlaceId)  {//EXAMPLE 1; reload all banners;
			for(var currentEmbed in tgEmbeds) {
				tgNS.loadBanner(
					tgEmbeds[currentEmbed].placeholderId,
					tgEmbeds[currentEmbed].requestSrc,
					tgNS.getSessionId()
				);
			}
		} else {//EXAMPLE 2; reload any banner;
			tgNS.loadBanner(
				tgEmbeds[bannerPlaceId].placeholderId,
				tgEmbeds[bannerPlaceId].requestSrc,
				tgNS.getSessionId()
			);
		}
	}

	/**
		Open API methods in namespace;
	*/
	
	tgNS.loadBanner = loadBanner;
	tgNS.getSessionId = getSessionId;
	tgNS.clearSession = clearSession;
	tgNS.initBanner = initBanner;
	tgNS.reloadBanners = reloadBanners;
})();

/*
** Имя функции, при вызове которой будет перезагружаться баннер.
** Если ни чего не указывать доступ к функция будет доступна в пространстве имен ADFOX (путь к функции) "window.ADFOX.RELOAD_CODE.reloadBanners".
** Поумолчанию передается "adfox_reloadBanner".
*/
(function(functionName){
	if (functionName) {
		window[functionName] = window.ADFOX.RELOAD_CODE.reloadBanners;
	}		
})('adfox_reloadBanner');
/*
     FILE ARCHIVED ON 10:14:46 Jun 17, 2017 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 19:28:33 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  LoadShardBlock: 64.443 (3)
  exclusion.robots: 0.314
  PetaboxLoader3.resolve: 75.239 (3)
  CDXLines.iter: 23.263 (3)
  PetaboxLoader3.datanode: 96.134 (5)
  exclusion.robots.policy: 0.294
  load_resource: 143.593
  esindex: 0.026
  RedisCDXSource: 1.04
  captures_list: 97.708
*/