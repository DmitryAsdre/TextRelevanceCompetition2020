function AdFox_getWindowSize(){var e,t;return"number"==typeof window.innerWidth?(e=window.innerWidth,t=window.innerHeight):document.documentElement&&(document.documentElement.clientWidth||document.documentElement.clientHeight)?(e=document.documentElement.clientWidth,t=document.documentElement.clientHeight):document.body&&(document.body.clientWidth||document.body.clientHeight)&&(e=document.body.clientWidth,t=document.body.clientHeight),{width:e,height:t}}function AdFox_getElementPosition(e){var t;document.getElementById?t=document.getElementById(e):document.layers?t=document.elemId:document.all&&(t=document.all.elemId);for(var o=t.offsetWidth,n=t.offsetHeight,d=0,c=0;t;)d+=t.offsetLeft,c+=t.offsetTop,t=t.offsetParent;return{left:d,top:c,width:o,height:n}}function AdFox_getBodyScrollTop(){return self.pageYOffset||document.documentElement&&document.documentElement.scrollTop||document.body&&document.body.scrollTop}function AdFox_getBodyScrollLeft(){return self.pageXOffset||document.documentElement&&document.documentElement.scrollLeft||document.body&&document.body.scrollLeft}function AdFox_Scroll(e,t){var o=AdFox_getWindowSize(),n=o.width,d=o.height,c=AdFox_getBodyScrollTop(),l=AdFox_getBodyScrollLeft(),m="AdFox_banner_"+e,i=AdFox_getElementPosition(m),u=i.left,r=i.top;c+d+5>=r&&l+n+5>=u?AdFox_getCodeScript(1,e,t):setTimeout("AdFox_Scroll("+e+',"'+t+'");',100)}
/*
     FILE ARCHIVED ON 20:53:14 Mar 13, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:53:24 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  load_resource: 101.886
  esindex: 0.011
  exclusion.robots: 0.202
  exclusion.robots.policy: 0.187
  PetaboxLoader3.datanode: 308.115 (5)
  captures_list: 1863.086
  RedisCDXSource: 2.754
  PetaboxLoader3.resolve: 1633.952 (3)
  CDXLines.iter: 12.157 (3)
  LoadShardBlock: 1844.759 (3)
*/