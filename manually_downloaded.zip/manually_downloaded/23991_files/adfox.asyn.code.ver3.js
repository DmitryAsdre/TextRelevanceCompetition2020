function AdFox_SetLayerVis(e,t){document.getElementById(e).style.visibility=t}function AdFox_Open(e){AdFox_SetLayerVis("AdFox_DivBaseFlash_"+e,"hidden"),AdFox_SetLayerVis("AdFox_DivOverFlash_"+e,"visible")}function AdFox_Close(e){AdFox_SetLayerVis("AdFox_DivOverFlash_"+e,"hidden"),AdFox_SetLayerVis("AdFox_DivBaseFlash_"+e,"visible")}function AdFox_getCodeScript(e,t,i){var a;if(10>e){try{document.all&&!window.opera?a=window.frames["AdFox_iframe_"+t].document:document.getElementById&&(a=document.getElementById("AdFox_iframe_"+t).contentDocument)}catch(o){}a?a.write('<script type="text/javascript" src="'+i+'"></script>'):setTimeout("AdFox_getCodeScript("+ ++e+","+t+',"'+i+'");',100)}}function adfoxSdvigContent(e,t,i){var a=document.getElementById("adfoxBanner"+e).style;a.width="100%"==t?t:t+"px",a.height="100%"==i?i:i+"px"}function adfoxVisibilityFlash(e,t,i){var a=document.getElementById(e).style;a.width="100%"==t?t:t+"px",a.height="100%"==i?i:i+"px"}function adfoxStart(e,t,i,a,o,d,n,s){1==t?adfoxVisibilityFlash("adfoxFlash1"+e,o,d):2==t&&(adfoxVisibilityFlash("adfoxFlash2"+e,n,s),"yes"==i&&adfoxVisibilityFlash("adfoxFlash1"+e,o,d),"yes"==a?adfoxSdvigContent(e,n,s):adfoxSdvigContent(e,o,d))}function adfoxOpen(e,t,i,a,o){var d=new Image,n=document.getElementById("aEventOpen"+e);n&&(d.src=n.title+"&rand="+1e6*Math.random()+"&prb="+1e6*Math.random()),adfoxVisibilityFlash("adfoxFlash2"+e,a,o),"yes"!=t&&adfoxVisibilityFlash("adfoxFlash1"+e,1,1),"yes"==i&&adfoxSdvigContent(e,a,o)}function adfoxClose(e,t,i,a,o){var d=new Image,n=document.getElementById("aEventClose"+e);n&&(d.src=n.title+"&rand="+1e6*Math.random()+"&prb="+1e6*Math.random()),adfoxVisibilityFlash("adfoxFlash2"+e,1,1),"yes"!=t&&adfoxVisibilityFlash("adfoxFlash1"+e,a,o),"yes"==i&&adfoxSdvigContent(e,a,o)}
/*
     FILE ARCHIVED ON 21:05:59 Mar 13, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:53:21 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  load_resource: 394.689
  esindex: 0.011
  exclusion.robots: 0.133
  exclusion.robots.policy: 0.124
  PetaboxLoader3.datanode: 204.34 (5)
  captures_list: 125.582
  RedisCDXSource: 37.848
  PetaboxLoader3.resolve: 255.961 (3)
  CDXLines.iter: 10.397 (3)
  LoadShardBlock: 74.596 (3)
*/