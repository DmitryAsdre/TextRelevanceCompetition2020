!function(e){e.fn.jTruncate=function(t){var i={length:300,minTrail:20,moreText:"more",lessText:"less",ellipsisText:"...",moreAni:"",lessAni:""},t=e.extend(i,t);return this.each(function(){obj=e(this);var i=obj.html();if(i.length>t.length+t.minTrail){var n=i.indexOf(" ",t.length);if(-1!=n){var n=i.indexOf(" ",t.length),o=i.substring(0,n),s=i.substring(n,i.length-1);obj.html(o+'<span class="truncate_ellipsis">'+t.ellipsisText+'</span><span class="truncate_more">'+s+"</span>"),obj.find(".truncate_more").css("display","none"),obj.append('<div class="clearboth"><a href="#" class="truncate_more_link">'+t.moreText+"</a></div>");var r=e(".truncate_more_link",obj),a=e(".truncate_more",obj),l=e(".truncate_ellipsis",obj);r.click(function(){return r.text()==t.moreText?(a.show(t.moreAni),r.text(t.lessText),l.css("display","none")):(a.hide(t.lessAni),r.text(t.moreText),l.css("display","inline")),!1})}}})}}(jQuery),$().ready(function(){$(".b-recipe_ingredients").jTruncate({length:100,minTrail:0,moreText:"[\u0435\u0449\u0451]",lessText:"[\u0441\u043f\u0440\u044f\u0442\u0430\u0442\u044c]",ellipsisText:"...",moreAni:"fast",lessAni:1e3})});
/*
     FILE ARCHIVED ON 17:48:52 Mar 14, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:52:40 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  RedisCDXSource: 0.573
  load_resource: 278.579
  esindex: 0.01
  captures_list: 136.595
  exclusion.robots.policy: 0.147
  exclusion.robots: 0.156
  PetaboxLoader3.datanode: 103.933 (5)
  CDXLines.iter: 16.384 (3)
  LoadShardBlock: 116.487 (3)
  PetaboxLoader3.resolve: 199.013 (2)
*/