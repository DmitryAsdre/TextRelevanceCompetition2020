window.ab = false;
/*
     FILE ARCHIVED ON 23:03:48 Nov 21, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 18:02:07 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  LoadShardBlock: 45.14 (3)
  CDXLines.iter: 14.645 (3)
  PetaboxLoader3.datanode: 888.052 (5)
  esindex: 0.016
  PetaboxLoader3.resolve: 143.987 (2)
  exclusion.robots: 0.202
  load_resource: 1006.509
  captures_list: 72.668
  RedisCDXSource: 7.3
  exclusion.robots.policy: 0.188
*/