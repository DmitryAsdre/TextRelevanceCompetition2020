/* PLEASE DO NOT COPY AND PASTE THIS CODE. */(function() {if (!window['___grecaptcha_cfg']) { window['___grecaptcha_cfg'] = {}; };if (!window['___grecaptcha_cfg']['render']) { window['___grecaptcha_cfg']['render'] = 'onload'; };window['__google_recaptcha_client'] = true;var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;po.src = 'http://web.archive.org/web/20161119182520/https://www.gstatic.com/recaptcha/api2/r20161109131337/recaptcha__en.js'; var elem = document.querySelector('script[nonce]');var nonce = elem && elem.getAttribute('nonce');if (nonce) { po.setAttribute('nonce', nonce); }var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);})();
/*
     FILE ARCHIVED ON 18:25:20 Nov 19, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 18:03:00 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  exclusion.robots: 0.175
  esindex: 0.013
  CDXLines.iter: 112.344 (3)
  PetaboxLoader3.datanode: 478.856 (8)
  load_resource: 270.912
  LoadShardBlock: 598.987 (6)
  PetaboxLoader3.resolve: 220.926 (3)
  RedisCDXSource: 263.496
  exclusion.robots.policy: 0.162
*/