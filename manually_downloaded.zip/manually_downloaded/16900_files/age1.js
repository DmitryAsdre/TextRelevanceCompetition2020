$(document).ready(function() {
     
     $(document.getElementById('age-accept')).click(function() {
          $.cookie('agecheck', '1', {'expires' : 360, 'path' : '/'});

     });
     
	 
if (window.matchMedia("(min-width: 999px)").matches) {
     if ($.cookie('agecheck') != '1')
          $(document.getElementById('basic-modal-content')).modal({
               'onClose': function (dialog) {
			   //
               //     if ($.cookie('agecheck') != '1')
               //          window.location = 'http://web.archive.org/web/20160316014454/http://www.yandex.ru/';
               //     else
                         $.modal.close();
               },
               'close': false
          });
} else {	 

     }
});

function getBrowserInfo() {
    var t,v = undefined;
    
    if (window.chrome) t = 'Chrome';
    else if (window.opera) t = 'Opera';
    else if (document.all) {
        t = 'IE';
        var nv = navigator.appVersion;
        var s = nv.indexOf('MSIE')+5;
        v = nv.substring(s,s+1);
    } 
    else if (navigator.appName) t = 'Netscape';
    
    return {type:t,version:v};
}

function bookmark(a){
    var url = "http://web.archive.org/web/20160316014454/http://www.russiansuka.ru/";
    var title = "Russiansuka.ru";
    var b = getBrowserInfo();
    
    if (b.type == 'IE' && 8 >= b.version && b.version >= 4) window.external.AddFavorite(url,title);
    else if (b.type == 'Opera') {
        a.href = url;
        a.rel = "sidebar";
        a.title = url+','+title;
        return true;
    }
    else if (b.type == "Netscape") window.sidebar.addPanel(title,url,"");
    else alert("Нажмите CTRL+D, чтобы добавить наш сайт в закладки.");
    return false;
} 


(function($){


	$(function(){
		var e = $(".scrollTop");
		var	speed = 500;

		e.click(function(){
			$("html:not(:animated)" +( !$.browser.opera ? ",body:not(:animated)" : "")).animate({ scrollTop: 0}, 500 );
			return false; //важно!
		});
		//появление
		function show_scrollTop(){
			( $(window).scrollTop()>300 ) ? e.fadeIn(600) : e.hide();
		}
		$(window).scroll( function(){show_scrollTop()} ); show_scrollTop();
	});

})(jQuery)
/*
     FILE ARCHIVED ON 01:44:54 Mar 16, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:56:04 May 16, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  RedisCDXSource: 13.379
  load_resource: 393.542
  esindex: 0.015
  captures_list: 695.595
  exclusion.robots.policy: 0.193
  exclusion.robots: 0.206
  PetaboxLoader3.datanode: 617.608 (5)
  CDXLines.iter: 11.322 (3)
  LoadShardBlock: 666.855 (3)
  PetaboxLoader3.resolve: 380.135 (3)
*/